# Circular-Slider-With-Jquery

![circularslider](https://user-images.githubusercontent.com/65412918/176988357-1934cd52-5fab-44a4-a7ba-d43e2348821f.png)
